import "./App.css";

function App() {
  return (
    <>
      <h1>Chúc các bạn thi tốt!</h1>
    </>
  );
}

export default App;
