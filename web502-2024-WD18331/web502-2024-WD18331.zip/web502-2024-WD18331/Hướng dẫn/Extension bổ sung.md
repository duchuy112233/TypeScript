```
Better Comments - đánh dấu các comment theo màu sắc
Code Runner - chạy code ngay trong file
Code Spell Checker - kiểm tra chính tả
Bracket Pair Colorizer 2 - đổ màu cho các đóng mở ngoặc
Javascript (ES6) code snippets - các snippets cho ES6
ES7 React/Redux/GraphQL/React-Native snippets - template cho React/Redux/GraphQL/React-Native
Auto Close Tag - cho html
Auto Rename Tag - cho html
Auto import - tự động import
Path Intellisense - gợi ý khi import
Import Cost - tính toán dung lượng của thư viện khi import
Git Lens - hiển thị thông tin commit
Git History - hiển thị lịch sử commit
Quokka.js - hiển thị kết quả ngay trong file
Error Lens - hiển thị lỗi ngay trong file
Console Ninja - hiển thị console.log ngay trong file khi gọi API hoặc render page
Prettier - Code formatter - format code
ESLint - kiểm tra lỗi code
vscode-icons - icon cho file
Dracula Official - theme màu sắc
```

- Một số extention cần cấu hình thêm mới có thể hoạt động.
