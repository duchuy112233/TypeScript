Thực hiện các hướng dẫn từ [link](../Hướng%20dẫn/Hướng%20dẫn%20cấu%20hình%20React%20Typescript.md)
để tạo ra dự án React Typescript cơ bản.
Tạo và tìm hiểu các config này, khi giảng viên hỏi cần giải thích được các bước làm và ý nghĩa của các thông số
.
