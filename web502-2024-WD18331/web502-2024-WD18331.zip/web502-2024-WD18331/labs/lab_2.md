Cho thông tin dữ liệu như file lab_2.json Hãy khai báo kiểu dữ liệu với từ khoá "type" cho các dự liệu bao gồm:

product, products, cart, carts, user, users
