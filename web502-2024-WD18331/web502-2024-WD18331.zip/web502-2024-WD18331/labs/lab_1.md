# 1: Cài đặt thành công typescipt và ts-node

```
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

```
npm i -g typescript ts-node ts-lib @types/node
```

- tsc -v
- ts-node -v
- tsc file.ts
- ts-node file.ts

# 2: Cài đặt thành công nvm và biết cách sử dụng các câu lệnh cơ bản:

- nvm list
- nvm use node_version
- nvm install node_version
- nvm install --lts
- nvm current

# 3: Cài đặt các extension giúp tối ưu công việc code:

```
Javascript (ES6) code snippets - các snippets cho ES6
ES7 React/Redux/GraphQL/React-Native snippets - template cho React/Redux/GraphQL/React-Native
Auto Close Tag - cho html
Auto Rename Tag - cho html
Auto import - tự động import
Path Intellisense - gợi ý khi import
Prettier - Code formatter - format code
vscode-icons - icon cho file

```
