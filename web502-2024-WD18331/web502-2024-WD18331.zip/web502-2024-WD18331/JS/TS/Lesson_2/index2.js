"use strict";
// Referent type
const projectOne = {
    id: 1,
    name: "E-commerce website",
    techStack: ["HTML", "CSS", "JS", "React", "NodeJS", "MongoDB"],
    summary: "Build a website to sell products online",
};
const myPortfolio = {
    fullName: "Nguyen Minh Hoang",
    birthDay: "1992-12-12",
    address: "Bac Giang",
    jobs: ["developer", "teacher", "grab driver"],
    company: "FPT Software",
    isMarried: true,
    projects: [
        {
            id: 1,
            name: "E-commerce website",
            techStack: ["HTML", "CSS", "JS", "React", "NodeJS", "MongoDB"],
            summary: "Build a website to sell products online",
        },
        {
            id: 1,
            name: "Binacy website",
            techStack: ["HTML", "CSS", "JS", "React", "NodeJS", "MongoDB"],
            summary: "Build a website to ...",
        },
    ],
    cetificate: [
        {
            id: 1,
            name: "English version B",
            major: "language",
            graduatedYear: 2013,
        },
    ],
};
const yourPortfolio = {
    fullName: "Nguyen Minh Hoang",
    birthDay: "1992-12-12",
    address: "Bac Giang",
    jobs: ["developer", "teacher", "grab driver"],
    company: "FPT Software",
    isMarried: true,
    projects: [
        {
            id: 1,
            name: "E-commerce website",
            techStack: ["HTML", "CSS", "JS", "React", "NodeJS", "MongoDB"],
            summary: "Build a website to sell products online",
        },
        {
            id: 1,
            name: "Binacy website",
            techStack: ["HTML", "CSS", "JS", "React", "NodeJS", "MongoDB"],
            summary: "Build a website to ...",
        },
    ],
};
