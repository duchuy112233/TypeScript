"use strict";
// ! Sử dụng ":" để khai báo cores type: string, number, boolean, array, object
// ! Sử dụng "type" để khai báo custom type
const myMessage = "Xin chao ca lop! Rat vui duoc day cac em!";
const myAge = 30;
const isMarried = false;
const mySkills = ["HTML", "CSS", "JS", "React", "NodeJS", "MongoDB"]; // Array of string
const myJobs = ["developer", "teacher", "grab dirver"]; // Generic array type
const myEducation = {
    school: "FPOLY",
    major: "Information Technology",
    graduatedYear: 2024,
    GPA: 3.5,
    sumary: "Good student",
};
const huongEducation = {
    school: "FPOLY",
    major: "Information Technology",
    graduatedYear: 2023,
    GPA: 4.0,
    sumary: "Excellent student",
};
