"use strict";
{
    const teachers = [
        "Tú",
        "Thắng",
        "Đạt",
        "Hoàng",
        "Huy",
        "Hoà",
        "Ngọc",
    ];
}
//! Cannot redeclare block-scoped variable 'teachers'.
//! Clearn code
var myString = "Hom nay troi dep qua!";
console.log(myString.toLowerCase());
console.log(myString.toLocaleUpperCase());
{
    const myInfor = {
        name: "Hoang Nguyen",
        age: 32,
        address: "Bắc Giang",
        jobs: ["developer", "teacher", "grab dirver"],
        company: "FPT Software",
        isMarried: true,
        gender: "lgbt+",
        hobbies: ["aoe", "lol", "pubg", "tiktok", "apple meowmeow", "tinder"],
    };
}
