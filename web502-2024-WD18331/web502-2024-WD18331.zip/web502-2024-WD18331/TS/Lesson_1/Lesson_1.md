1. Cài đặt ts và ts-node

```
tsc -v
tsc index.ts
ts-node -v
ts-node index.ts
```

2. Cài đặt extension cho vscode
   code runner
   error lens
