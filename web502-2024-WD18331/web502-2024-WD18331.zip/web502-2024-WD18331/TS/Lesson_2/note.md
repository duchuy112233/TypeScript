1. extension

- vscode - icons
- prettier - code formatter:

  Bước 1: Cài đặt extension Prettier - Code formatter
  Bước 2: Setting -> search "format on save" -> check "Editor: Format On Save".
  Bước 3: Setting -> search "auto save" -> check "Files: Auto Save" -> "onWindowChange".
  Bước 4: Setting -> search "default formatter" -> chọn "Prettier - Code formatter".
